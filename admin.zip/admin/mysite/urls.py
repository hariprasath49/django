from django.contrib import admin
from django.urls import path, include

from mysite.core import views
# from rest_framework.decorators import api_view
# from rest_framework.response import Response
# from rest_framework.reverse import reverse

urlpatterns = [
    path('', views.home, name='home'),
    path('newhome', views.basehome, name='newhome'),
    path('signup/', views.signup, name='signup'),
    path('secret/', views.secret_page, name='secret'),
    path('contact/', views.contact, name='contact'),
    path('payment/', views.subscribe_plans, name='payment'),
    path('secret2/', views.SecretPage.as_view(), name='secret2'),
    path('accounts/', include('django.contrib.auth.urls')),
    path('admin/', admin.site.urls),
    path('newsletter/',include('newsletter.urls' , namespace='newsletter')),
    path('payment_pay/',views.subscribe_plans,name='payment-form'),
    path('payment_plan1/',views.process_subscription,name='payment-form'),
    path('payment_plan2/',views.process_subscription_lifetime,name='payment-form'),
    # path('payment_pay',views.payment_pay,name='payment-form'),
    
    # path('process-payment/', views.payment_pay, name='process_payment'),
    # path('payment-done/', views.payment_done, name='payment_done'),
    # path('payment-cancelled/', views.payment_canceled, name='payment_cancelled'),
    path('subscribe_plan/', views.subscription, name='subscription'),
    path('process_subscription/', views.process_subscription_new, name='process_subscription'),
    # path('process_subscription/', views.process_subscription, name='process_subscription'),
    ]
