from django import forms
#...

subscription_options = [
    ('1-month', '1-Month subscription ($10 USD)'),
    ('6-month', '6-Month subscription ($49 USD)'),
    ('Life time', 'Life Time subscription ($99 USD)'),
]
 
 
class SubscriptionForm(forms.Form):
    plans = forms.ChoiceField(choices=subscription_options)

