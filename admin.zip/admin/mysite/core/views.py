from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.decorators import login_required
from django.views.generic import TemplateView
from django.contrib.auth.mixins import LoginRequiredMixin
from django.conf import settings
from django.urls import reverse
from django.shortcuts import render, get_object_or_404
from paypal.standard.forms import PayPalPaymentsForm
from django.views.decorators.csrf import csrf_exempt 
from .forms import SubscriptionForm

@csrf_exempt
def payment_canceled(request):
    return render(request, 'payment/payment_cancel.html')
 
 
def subscription(request):
    if request.method == 'POST':
        f = SubscriptionForm(request.POST)
        if f.is_valid():
            request.session['subscription_plan'] = request.POST.get('plans')
            return redirect('process_subscription')
    else:
        f = SubscriptionForm()
    return render(request, 'payment_test.html', locals())

def home(request):
    count = User.objects.count()
    return render(request, 'home.html', {
        'count': count
    })

def basehome(request):
    return render(request, 'base.html')

def contact(request):
    return render(request, 'contact.html')

def payment_page(request):
    return render(request, 'payment_test.html')

def payment_done(request):
    return render(request, 'payment_done.html')

def signup(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('home')
    else:
        form = UserCreationForm()
    return render(request, 'registration/signup.html', {
        'form': form
    })

def subscribe_plans(request):
    return render(request, 'payment/payment_done.html')


@login_required
def secret_page(request):
    return render(request, 'secret_page.html')


class SecretPage(LoginRequiredMixin, TemplateView):
    template_name = 'secret_page.html'



def process_subscription(request):
    paypal_dict = {
        "cmd": "_xclick-subscriptions",
        "business": 'rajan_api1.shandinfotech.com',
        "a3": "49.0",                      # monthly price
        "p3": 1,                           # duration of each unit (depends on unit)
        "t3": "Y",                         # duration unit ("M for Month")
        "src": "1",                        # make payments recur
        "sra": "1",                        # reattempt payment on payment error
        "no_note": "1",                    # remove extra notes (optional)
        "item_name": "Course 1",
        'currency_code': 'USD',
        "notify_url": "http://www.example.com/your-ipn-location/",
        "return": "http://www.example.com/your-return-location/",
        "cancel_return": "payment/payment_cancel.html",
}

# Create the instance.
    form = PayPalPaymentsForm(initial=paypal_dict, button_type="subscribe")

# Output the button.
    return render(request, 'payment/plan1.html', locals())

def process_subscription_lifetime(request):
    paypal_dict = {
        "cmd": "_xclick-subscriptions",
        "business": 'rajan_api1.shandinfotech.com',
        "a3": "99.0",                      # monthly price
        "p3": 99,                           # duration of each unit (depends on unit)
        "t3": "Y",                         # duration unit ("M for Month")
        "src": "1",                        # make payments recur
        "sra": "1",                        # reattempt payment on payment error
        "no_note": "1",                    # remove extra notes (optional)
        "item_name": "Course 2",
        'currency_code': 'USD',
        "notify_url": "http://www.example.com/your-ipn-location/",
        "return": "http://www.example.com/your-return-location/",
        "cancel_return": "payment/payment_cancel.html",
}

# Create the instance.
    form = PayPalPaymentsForm(initial=paypal_dict, button_type="subscribe")

# Output the button.
    return render(request, 'payment/plan2.html', locals())

def process_subscription_new(request):
 
    subscription_plan = request.session.get('subscription_plan')
    host = request.get_host()
 
    if subscription_plan == '1-month':
        price = "10"
        billing_cycle = 1
        billing_cycle_unit = "M"

    elif subscription_plan == '6-month':
        price = "49"
        billing_cycle = 6
        billing_cycle_unit = "M"

    else:
        price = "99"
        billing_cycle = 99
        billing_cycle_unit = "Y"
 
 
    paypal_dict  = {
        "cmd": "_xclick-subscriptions",
        'business': settings.PAYPAL_RECEIVER_EMAIL,
        "a3": price,  # monthly price
        "p3": billing_cycle,  # duration of each unit (depends on unit)
        "t3": billing_cycle_unit,  # duration unit ("M for Month")
        "src": "1",  # make payments recur
        "sra": "1",  # reattempt payment on payment error
        "no_note": "1",  # remove extra notes (optional)
        'item_name': 'Content subscription',
        'custom': 1,     # custom data, pass something meaningful here
        'currency_code': 'USD',
        "notify_url": "payment/payment_notify.html",
        "return": "payment/payment_return.html",
        "cancel_return": "payment/payment_cancel.html",
    }
 
    form = PayPalPaymentsForm(initial=paypal_dict, button_type="subscribe")
    return render(request, 'payment_test2.html', locals())  